export default {
    iconLinks: [
      {
        icon: 'github',
        href: 'https://github.com/sshnet/SSH.NET',
        title: 'GitHub'
      }
    ]
  }