﻿#if NET6_0_OR_GREATER
using System.Diagnostics.CodeAnalysis;

[assembly: ExcludeFromCodeCoverage]
#endif // NET6_0_OR_GREATER
